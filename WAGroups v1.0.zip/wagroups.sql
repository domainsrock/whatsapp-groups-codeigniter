create table categories
(
    srid int AUTO_INCREMENT primary key,
    name varchar(50) unique not null,
    slug varchar(80) unique not null,
    hits bigint default 0,
    descriptions varchar(100) default 'Get Latest News, Jokes, Videos and Funny Entertainments for Free'
)

create table grouplinks
(
    srid int AUTO_INCREMENT primary key,
    catg varchar(10) not null,
    link varchar(100) unique not null,
    slug varchar(150) unique not null,
    name varchar(100) not null,
    hits int default 0,
    clicks int default 0,
    status int default 0,
    premium int default 0,
    ratingcount int default 0,
    ratingusers int default 0,
    description varchar(100) default 'Join this Whatsapp Groups to Get Latest News, Jokes, Videos and Funny Entertainments for Free'
)