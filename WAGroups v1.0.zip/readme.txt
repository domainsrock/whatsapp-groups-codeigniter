How to Install WAGroups
----------------------------------------------------------
1. Upload File on Hosting Server
2. Create SQL Database and Users
3. Open PhpMyAdmin and Import SQL File
4. Open Folder application -> config -> config.php and Update Domain
5. Open Folder application -> config -> database.php and Update Database
6. Setup is Completed. Now Run Your Website and Start Using.